/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe.edu.uni.proyecto1_torre.controller;
import pe.edu.uni.proyecto1_torre.service.SerieService;

public class SerieController {
    public double SumaN(int n){
        SerieService service = new SerieService();
        return service.CalcularSerie(n);
    }
}
