/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe.edu.uni.proyecto1_torre.controller;
import pe.edu.uni.proyecto1_torre.service.AmstrongService;


public class AmstrongController {
    
    public int SumaN(int n){
        AmstrongService service = new AmstrongService();
        return service.SumaNumero(n);
    }
    
    public boolean Comprob(int n){
        AmstrongService service = new AmstrongService();
        return service.Comprobar(n);
    }
}
