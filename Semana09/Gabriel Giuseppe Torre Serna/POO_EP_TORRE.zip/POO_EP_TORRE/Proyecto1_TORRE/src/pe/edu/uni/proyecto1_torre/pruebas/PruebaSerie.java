/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe.edu.uni.proyecto1_torre.pruebas;

import pe.edu.uni.proyecto1_torre.service.SerieService;


public class PruebaSerie {
    public static void main(String[] args) {
        
	try {
            // Datos
            int n1 = 2;
            int n2 = 10;
            int n3 = 50;

            // Proceso
            SerieService service = new SerieService();
            double sn1 = service.CalcularSerie(n1);
            double sn2 = service.CalcularSerie(n2);
            double sn3 = service.CalcularSerie(n3);
            
            // Reporte
            System.out.println("N1: " + n1 + "\nSerie: " + sn1);
            System.out.println("\nN2: " + n2 + "\nSerie: " + sn2);
            System.out.println("\nN3: " + n2 + "\nSerie: " + sn3);
            
        } catch (Exception e) {
            System.err.println(e.getMessage());
	} finally{
            System.out.println("\nFin del programa");
	}
    }
}
