/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe.edu.uni.proyecto1_torre.service;

public class SerieService {
    public double CalcularSerie(int n){
        if(n<=0){
            throw new RuntimeException("Ingresar un número mayor a 0");
        }
        double s=0;
        for(double i=1; i<=n; i++){
            s += 1/i;
        }
        return s;
    }
}
