/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe.edu.uni.proyecto1_torre.service;


public class AmstrongService {
    public int SumaNumero(int n){
        if(n<0){
            throw new RuntimeException("Ingresar un número no negativo");
        }
        int n2=0, cif=0;
        
        for(int i=n; i!=0; i/=10){
            cif+=1;
        }
        
        for(int i=n; i!=0; i/=10){
            n2 += Math.pow(i%10, cif);
        }
        
        return(n2);
    }
    
    public boolean Comprobar(int n){
        if(SumaNumero(n) == n){
            return(true);
        }
        else return(false);
    }
    
}
