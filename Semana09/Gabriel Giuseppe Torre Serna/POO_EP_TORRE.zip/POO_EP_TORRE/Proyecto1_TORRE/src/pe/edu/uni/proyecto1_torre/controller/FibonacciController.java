/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe.edu.uni.proyecto1_torre.controller;

import pe.edu.uni.proyecto1_torre.service.FibonacciService;


public class FibonacciController {
    public int[] calcularFibonacci(int n) {
        FibonacciService service = new FibonacciService();
        return service.calcularFibonacci(n);
    }
}
