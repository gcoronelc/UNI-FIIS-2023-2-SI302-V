/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe.edu.uni.proyecto1_torre.service;

/**
 *
 * @author Brayan Rojas
 */
public class FibonacciService {

    public int[] calcularFibonacci(int n) {
        if (n <= 0) {
            throw new RuntimeException("Ingresar un número mayor a 0");
        }

        int[] fibSerie = new int[n];
        fibSerie[0] = 0;
        if (n > 1) {
            fibSerie[1] = 1;
        }

        for (int i = 2; i < n; i++) {
            fibSerie[i] = fibSerie[i - 1] + fibSerie[i - 2];
        }
        return fibSerie;
        
    }
}


