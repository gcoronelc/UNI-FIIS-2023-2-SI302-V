package pe.edu.uni.proyecto1_torre;
import pe.edu.uni.proyecto1_torre.view.Vista;
/**
 *
 * @author Gabriel Torre
 */
public class Proyecto1_TORRE {
    public static void main(String[] args) {
        Vista.main(args);
    }
}
