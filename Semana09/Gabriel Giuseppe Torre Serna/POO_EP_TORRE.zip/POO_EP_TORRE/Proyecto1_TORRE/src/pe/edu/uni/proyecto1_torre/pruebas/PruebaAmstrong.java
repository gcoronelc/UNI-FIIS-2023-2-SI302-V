/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe.edu.uni.proyecto1_torre.pruebas;

import pe.edu.uni.proyecto1_torre.service.AmstrongService;

public class PruebaAmstrong {
    public static void main(String[] args) {
	try {
            // Datos
            int n1 = 371;
            int n2 = 382;

            // Proceso
            AmstrongService service = new AmstrongService();
            int sn1 = service.SumaNumero(n1);
            int sn2 = service.SumaNumero(n2);
            
            // Reporte
            System.out.println("N1: " + n1 + "\nSuma: " + sn1);
            if(service.Comprobar(n1)){
                System.out.println("ES un numero de Amstrong");
            }
            else{
                System.out.println("NO es un numero de Amstrong");
            }
            
            System.out.println("\nN2: " + n2 + "\nSuma: " + sn2);
            if(service.Comprobar(n2)){
                System.out.println("ES un numero de Amstrong");
            }
            else{
                System.out.println("NO es un numero de Amstrong");
            }
            
            
        } catch (Exception e) {
            System.err.println(e.getMessage());
	} finally{
            System.out.println("\nFin del programa");
	}
    }
}
