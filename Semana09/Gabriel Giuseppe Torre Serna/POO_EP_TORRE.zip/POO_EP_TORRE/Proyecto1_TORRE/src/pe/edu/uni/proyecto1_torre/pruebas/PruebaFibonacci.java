/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe.edu.uni.proyecto1_torre.pruebas;

import pe.edu.uni.proyecto1_torre.service.FibonacciService;


public class PruebaFibonacci {

    public static void main(String[] args) {
        try {
            // Datos
            int n1 = 5;
            int n2 = 15;
            int n3 = 20;

            // Proceso
            FibonacciService fibonacciService = new FibonacciService();
            int[] fibonacciN1 = fibonacciService.calcularFibonacci(n1);
            int[] fibonacciN2 = fibonacciService.calcularFibonacci(n2);
            int[] fibonacciN3 = fibonacciService.calcularFibonacci(n3);

            // Reporte
            System.out.println("N1: " + n1 + "\nSerie: " + arrayToString(fibonacciN1));
            System.out.println("\nN2: " + n2 + "\nSerie: " + arrayToString(fibonacciN2));
            System.out.println("\nN3: " + n3 + "\nSerie: " + arrayToString(fibonacciN3));

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            System.out.println("\nFin del programa");
        }
    }

    private static String arrayToString(int[] arr) {
        StringBuilder result = new StringBuilder();
        for (int num : arr) {
            result.append(num).append(" ");
        }
        return result.toString().trim();
    }
}

