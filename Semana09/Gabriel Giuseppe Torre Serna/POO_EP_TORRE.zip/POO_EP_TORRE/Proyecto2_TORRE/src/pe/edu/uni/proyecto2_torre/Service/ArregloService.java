/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe.edu.uni.proyecto2_torre.Service;

import java.util.HashSet;
import java.util.Random;
import java.util.Set;

public class ArregloService {

    private int[] arreglo1;
    private int[] arreglo2;

    public ArregloService(int n) {
        arreglo1 = generarArregloAleatorio(n);
        arreglo2 = generarArregloAleatorio(n);
    }

    public int[] getArreglo1() {
        return arreglo1;
    }

    public int[] getArreglo2() {
        return arreglo2;
    }

    public int[] arregloDiferencia() {
        Set<Integer> set1 = new HashSet<>();
        Set<Integer> set2 = new HashSet<>();

        for (int num : arreglo1) {
            set1.add(num);
        }

        for (int num : arreglo2) {
            set2.add(num);
        }

        set1.removeAll(set2);

        int[] diferencia = new int[set1.size()];
        int index = 0;
        for (int num : set1) {
            diferencia[index++] = num;
        }

        return diferencia;
    }

    public int[] arregloInterseccion() {
        Set<Integer> set1 = new HashSet<>();
        Set<Integer> set2 = new HashSet<>();

        for (int num : arreglo1) {
            set1.add(num);
        }

        for (int num : arreglo2) {
            set2.add(num);
        }

        set1.retainAll(set2);

        int[] interseccion = new int[set1.size()];
        int index = 0;
        for (int num : set1) {
            interseccion[index++] = num;
        }

        return interseccion;
    }

    private int[] generarArregloAleatorio(int n) {
        Random random = new Random();
        int[] arreglo = new int[n];
        for (int i = 0; i < n; i++) {
            arreglo[i] = random.nextInt(10) + 21; // Números aleatorios en el rango [21, 30]
        }
        return arreglo;
    }

}