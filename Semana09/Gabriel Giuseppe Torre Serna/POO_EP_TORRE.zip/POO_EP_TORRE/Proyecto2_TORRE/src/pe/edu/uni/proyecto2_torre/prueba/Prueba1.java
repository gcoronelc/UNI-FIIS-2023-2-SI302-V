/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe.edu.uni.proyecto2_torre.prueba;

import pe.edu.uni.proyecto2_torre.Service.ArregloService;

public class Prueba1 {
    public static void main(String[] args) {
        //Datos
        int n = 10;
        
        //Proceso
        ArregloService servicio = new ArregloService(n);
        int[] arreglo1 = servicio.getArreglo1();
        int[] arreglo2 = servicio.getArreglo2();
        int[] diferencia = servicio.arregloDiferencia();
        int[] interseccion = servicio.arregloInterseccion();
        
        //Reporte
        System.out.println("Arreglo 1: " + arrayToString(arreglo1));
        System.out.println("Arreglo 2: " + arrayToString(arreglo2));
        System.out.println("Diferencia: " + arrayToString(diferencia));
        System.out.println("Interseccion: " + arrayToString(interseccion));
    }
    
    
    private static String arrayToString(int[] arr) {
        StringBuilder result = new StringBuilder();
        result.append("[");
        for (int i = 0; i < arr.length; i++) {
            result.append(arr[i]);
            if (i < arr.length - 1) {
                result.append(", ");
            }
        }
        result.append("]");
        return result.toString();
    }
}
