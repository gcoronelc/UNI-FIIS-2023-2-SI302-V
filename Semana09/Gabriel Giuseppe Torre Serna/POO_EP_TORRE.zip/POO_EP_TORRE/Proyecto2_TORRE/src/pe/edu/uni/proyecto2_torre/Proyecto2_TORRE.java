/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe.edu.uni.proyecto2_torre;

import pe.edu.uni.proyecto2_torre.view.Vista;

public class Proyecto2_TORRE {
    public static void main(String[] args) {
        Vista.main(args);
    }
}
